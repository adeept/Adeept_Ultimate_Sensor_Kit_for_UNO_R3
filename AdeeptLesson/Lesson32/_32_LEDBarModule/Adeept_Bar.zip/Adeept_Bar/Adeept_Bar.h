/*
  LED bar library V1.0
  2015 Copyright (c) Adeept Technology Inc.  All right reserved.
  Author: TOM
*/
#ifndef Adeept_Bar_H
#define Adeept_Bar_H

#include <Arduino.h>

// Avoid name conflict
#define GLB_CMDMODE 0x00  // Work on 8-bit mode
#define GLB_ON      0xff             // 8-bit 1 data
#define GLB_OFF     0x00          // 8-bit 0 data

class Adeept_Bar
{
private:

  unsigned int __pinClock;  // Clock pin
  unsigned int __pinData;   // Data pin
  unsigned char __state[10];// Led state, brightness for each LED

  void sendData(unsigned int data);  // Send a word to led bar
  void latchData(void);              // Load data into the latch register
  void setData(unsigned char bits[]);//Set data array

public:

  Adeept_Bar(unsigned char pinClock, unsigned char pinData);  // Initialize
  void begin(){pinMode(__pinClock, OUTPUT); pinMode(__pinData, OUTPUT);}
  void setBits(unsigned int bits);                 // Set the display of data
};

#endif